import UIKit

var str = "Hello, playground"

var shoecollection: [String] = ["vapormaxes pros, airforces, kyries rainbow addition, Jordan 12s"]
shoecollection.append("vapormaxes pros,Jordan 12s")

print (shoecollection)
